twitchNotifications
===================

A chrome extension that notifies the user when a followed channel starts streaming.
